"""
Настройка нового узла: создаёт в 3x-ui инбаунд VLESS+Reality.

Reality делает так, что TLS-хендшейк вашего сервера неотличим от хендшейка
настоящего сайта (target/dest) — DPI видит обычное HTTPS-соединение
к легитимному домену, а не сигнатуру прокси. Это сейчас самый устойчивый
вариант против блокировок в духе российских allow-list/DPI-механизмов.

Использование:
    python setup_node.py --api-url https://1.2.3.4:54321/panelpath \
        --user admin --password admin_pass \
        --dest addons.mozilla.org:443 --port 443

dest — реальный сайт, под который мы маскируемся. Берите крупный, быстрый,
не заблокированный в РФ ресурс с поддержкой TLS 1.3 и X25519 (Cloudflare-based
сайты, крупные CDN — хороший выбор). НЕ используйте один и тот же dest на всех
нодах — так проще фингерпринтить весь ваш пул серверов по паттерну.
"""
import argparse
import json
import subprocess
import sys

import httpx


def generate_x25519_keypair(xray_bin: str = "xray") -> tuple[str, str]:
    """Генерирует пару ключей Reality через сам бинарник xray-core на сервере."""
    result = subprocess.run([xray_bin, "x25519"], capture_output=True, text=True, check=True)
    private_key = None
    public_key = None
    for line in result.stdout.splitlines():
        if line.startswith("Private key:"):
            private_key = line.split(":", 1)[1].strip()
        elif line.startswith("Public key:"):
            public_key = line.split(":", 1)[1].strip()
    if not private_key or not public_key:
        raise RuntimeError(f"не удалось распарсить вывод xray x25519: {result.stdout}")
    return private_key, public_key


def create_reality_inbound(
    api_url: str,
    username: str,
    password: str,
    dest: str,
    port: int,
    private_key: str,
    public_key: str,
    short_id: str,
    remark: str = "reality-main",
    verify_ssl: bool = False,
) -> dict:
    client = httpx.Client(base_url=api_url.rstrip("/"), verify=verify_ssl, timeout=15)

    login = client.post("/login", data={"username": username, "password": password})
    login.raise_for_status()
    if not login.json().get("success"):
        raise RuntimeError("логин в 3x-ui не удался")

    server_name = dest.split(":")[0]

    stream_settings = {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
            "show": False,
            "dest": dest,
            "xver": 0,
            "serverNames": [server_name],
            "privateKey": private_key,
            "shortIds": [short_id],
            "settings": {
                "publicKey": public_key,
                "fingerprint": "chrome",
                "serverName": server_name,
                "spiderX": "/",
            },
        },
        "tcpSettings": {
            "header": {"type": "none"},
        },
    }

    inbound_payload = {
        "up": 0,
        "down": 0,
        "total": 0,
        "remark": remark,
        "enable": True,
        "expiryTime": 0,
        "listen": "",
        "port": port,
        "protocol": "vless",
        "settings": json.dumps({
            "clients": [],
            "decryption": "none",
            "fallbacks": [],
        }),
        "streamSettings": json.dumps(stream_settings),
        "sniffing": json.dumps({
            "enabled": True,
            "destOverride": ["http", "tls", "quic"],
        }),
    }

    resp = client.post("/panel/api/inbounds/add", json=inbound_payload)
    resp.raise_for_status()
    data = resp.json()
    if not data.get("success"):
        raise RuntimeError(f"создание инбаунда не удалось: {data}")

    return data["obj"]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--api-url", required=True)
    parser.add_argument("--user", required=True)
    parser.add_argument("--password", required=True)
    parser.add_argument("--dest", default="addons.mozilla.org:443", help="сайт для маскировки, host:port")
    parser.add_argument("--port", type=int, default=443)
    parser.add_argument("--short-id", default="6ba85179e30d4fc2")
    parser.add_argument("--xray-bin", default="xray", help="путь к бинарнику xray на сервере, если запускается локально на ноде")
    parser.add_argument("--verify-ssl", action="store_true", help="проверять TLS-сертификат панели (по умолчанию выключено — большинство инсталляций 3x-ui используют самоподписанный сертификат)")
    args = parser.parse_args()

    try:
        priv, pub = generate_x25519_keypair(args.xray_bin)
    except (FileNotFoundError, subprocess.CalledProcessError):
        print("Не удалось вызвать xray x25519 локально.")
        print("Сгенерируйте ключи на самой ноде командой `xray x25519` и передайте вручную,")
        print("либо запустите этот скрипт прямо на ноде, где установлен xray-core (идёт вместе с 3x-ui).")
        sys.exit(1)

    inbound = create_reality_inbound(
        api_url=args.api_url,
        username=args.user,
        password=args.password,
        dest=args.dest,
        port=args.port,
        private_key=priv,
        public_key=pub,
        short_id=args.short_id,
        verify_ssl=args.verify_ssl,
    )

    print("Инбаунд создан:")
    print(json.dumps(inbound, indent=2, ensure_ascii=False))
    print(f"\nСохраните inbound_id={inbound['id']} — он понадобится в поле Node.inbound_id")
    print(f"Public key для клиентов: {pub}  (private key остаётся только на сервере)")
