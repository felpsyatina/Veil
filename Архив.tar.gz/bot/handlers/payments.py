"""
Оплата.

Telegram Stars: нативный send_invoice с currency="XTR", подтверждение приходит
автоматически через successful_payment — никакого внешнего шлюза не нужно.

Карта РФ: через ЮKassa (yookassa.ru) — принимает МИР и российские Visa/MC.
Крипта (USDT и т.д.): через NOWPayments (или любой похожий шлюз с REST API).

Для карты и крипты здесь реализован вариант "создать платёж -> дать ссылку ->
пользователь жмёт 'Я оплатил' -> бот проверяет статус в шлюзе".
В проде лучше добавить приём вебхука прямо на бэкенд (ЮKassa шлёт уведомления
на URL, который вы укажете в настройках магазина; у NOWPayments это IPN),
чтобы не зависеть от того, нажал ли юзер кнопку.
"""
import uuid
import httpx
from aiogram import Router, F
from aiogram.types import CallbackQuery, LabeledPrice, PreCheckoutQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from ..keyboards.menus import back_to_menu
from .. import api_client
from ..config import NOWPAYMENTS_API_KEY, YOOKASSA_SHOP_ID, YOOKASSA_SECRET_KEY, BOT_USERNAME

router = Router()


# ---------------- Telegram Stars ----------------

@router.callback_query(F.data.startswith("pay:stars:"))
async def pay_with_stars(callback: CallbackQuery):
    plan_id = int(callback.data.split(":")[2])
    plans = await api_client.get_plans()
    plan = next((p for p in plans if p["id"] == plan_id), None)
    if not plan or not plan.get("price_stars"):
        await callback.answer("Тариф недоступен для оплаты в Stars", show_alert=True)
        return

    order_id = await api_client.create_order(
        telegram_id=callback.from_user.id,
        plan_id=plan_id,
        payment_method="stars",
        username=callback.from_user.username,
    )

    await callback.bot.send_invoice(
        chat_id=callback.from_user.id,
        title=f"Подписка: {plan['name']}",
        description=f"VPN-доступ на {plan['duration_days']} дней, несколько серверов",
        payload=f"order:{order_id}",
        currency="XTR",
        prices=[LabeledPrice(label=plan["name"], amount=plan["price_stars"])],
    )
    await callback.answer()


@router.pre_checkout_query()
async def pre_checkout(pcq: PreCheckoutQuery):
    # тут можно ещё раз сверить актуальность заказа/цены перед подтверждением
    await pcq.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message):
    payload = message.successful_payment.invoice_payload  # "order:123"
    order_id = int(payload.split(":")[1])

    result = await api_client.confirm_order(
        order_id=order_id,
        payment_ref=message.successful_payment.telegram_payment_charge_id,
    )

    await message.answer(
        "✅ Оплата получена, доступ создан!\n\n"
        f"Ссылка на подписку:\n`{result['sub_url']}`\n\n"
        "Вставьте её в приложение (v2rayNG, NekoBox, Hiddify, Streisand) "
        "как источник подписки — оно само подтянет все серверы.",
        parse_mode="Markdown",
        reply_markup=back_to_menu(),
    )


# ---------------- Карта РФ (ЮKassa) ----------------

@router.callback_query(F.data.startswith("pay:card:"))
async def pay_with_card(callback: CallbackQuery):
    plan_id = int(callback.data.split(":")[2])
    plans = await api_client.get_plans()
    plan = next((p for p in plans if p["id"] == plan_id), None)
    if not plan or not plan.get("price_rub"):
        await callback.answer("Тариф недоступен для оплаты картой", show_alert=True)
        return

    order_id = await api_client.create_order(
        telegram_id=callback.from_user.id,
        plan_id=plan_id,
        payment_method="card_ru",
        username=callback.from_user.username,
    )

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "https://api.yookassa.ru/v3/payments",
            auth=(YOOKASSA_SHOP_ID, YOOKASSA_SECRET_KEY),
            headers={"Idempotence-Key": str(uuid.uuid4())},
            json={
                "amount": {"value": f"{float(plan['price_rub']):.2f}", "currency": "RUB"},
                "confirmation": {
                    "type": "redirect",
                    "return_url": f"https://t.me/{BOT_USERNAME}",
                },
                "capture": True,
                "description": f"VPN подписка: {plan['name']}",
                "metadata": {"order_id": str(order_id)},
            },
            timeout=15,
        )
        resp.raise_for_status()
        payment = resp.json()

    kb = InlineKeyboardBuilder()
    kb.button(text="💳 Оплатить картой", url=payment["confirmation"]["confirmation_url"])
    kb.button(text="✅ Я оплатил", callback_data=f"checkcard:{order_id}:{payment['id']}")
    kb.adjust(1)

    await callback.message.edit_text(
        f"Счёт на {plan['price_rub']}₽ создан.\n"
        "После оплаты вернитесь в бота и нажмите «Я оплатил».",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("checkcard:"))
async def check_card_payment(callback: CallbackQuery):
    _, order_id, payment_id = callback.data.split(":")

    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"https://api.yookassa.ru/v3/payments/{payment_id}",
            auth=(YOOKASSA_SHOP_ID, YOOKASSA_SECRET_KEY),
            timeout=15,
        )
        resp.raise_for_status()
        payment = resp.json()

    if payment.get("status") == "succeeded":
        result = await api_client.confirm_order(order_id=int(order_id), payment_ref=payment_id)
        await callback.message.edit_text(
            "✅ Оплата подтверждена, доступ создан!\n\n"
            f"Ссылка на подписку:\n`{result['sub_url']}`",
            parse_mode="Markdown",
            reply_markup=back_to_menu(),
        )
    elif payment.get("status") == "canceled":
        await callback.message.edit_text(
            "❌ Платёж отменён или не прошёл. Попробуйте оформить заново через «Купить подписку».",
            reply_markup=back_to_menu(),
        )
    else:
        await callback.answer("Платёж пока не подтверждён, попробуйте через минуту", show_alert=True)


# ---------------- Крипта (NOWPayments) ----------------

@router.callback_query(F.data.startswith("pay:crypto:"))
async def pay_with_crypto(callback: CallbackQuery):
    plan_id = int(callback.data.split(":")[2])
    plans = await api_client.get_plans()
    plan = next((p for p in plans if p["id"] == plan_id), None)
    if not plan or not plan.get("price_usdt"):
        await callback.answer("Тариф недоступен для оплаты в крипте", show_alert=True)
        return

    order_id = await api_client.create_order(
        telegram_id=callback.from_user.id,
        plan_id=plan_id,
        payment_method="crypto",
        username=callback.from_user.username,
    )

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "https://api.nowpayments.io/v1/invoice",
            headers={"x-api-key": NOWPAYMENTS_API_KEY},
            json={
                "price_amount": float(plan["price_usdt"]),
                "price_currency": "usd",
                "pay_currency": "usdttrc20",
                "order_id": str(order_id),
                "order_description": f"VPN подписка: {plan['name']}",
            },
            timeout=15,
        )
        resp.raise_for_status()
        invoice = resp.json()

    kb = InlineKeyboardBuilder()
    kb.button(text="💳 Перейти к оплате", url=invoice["invoice_url"])
    kb.button(text="✅ Я оплатил", callback_data=f"checkpay:{order_id}:{invoice['id']}")
    kb.adjust(1)

    await callback.message.edit_text(
        f"Счёт на {plan['price_usdt']} USDT создан.\n"
        "После оплаты нажмите «Я оплатил» — обычно подтверждение приходит "
        "в течение пары минут.",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("checkpay:"))
async def check_crypto_payment(callback: CallbackQuery):
    _, order_id, invoice_payment_id = callback.data.split(":")

    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"https://api.nowpayments.io/v1/payment/{invoice_payment_id}",
            headers={"x-api-key": NOWPAYMENTS_API_KEY},
            timeout=15,
        )
        resp.raise_for_status()
        payment = resp.json()

    if payment.get("payment_status") in ("finished", "confirmed"):
        result = await api_client.confirm_order(order_id=int(order_id), payment_ref=invoice_payment_id)
        await callback.message.edit_text(
            "✅ Оплата подтверждена, доступ создан!\n\n"
            f"Ссылка на подписку:\n`{result['sub_url']}`",
            parse_mode="Markdown",
            reply_markup=back_to_menu(),
        )
    else:
        await callback.answer("Платёж пока не найден, попробуйте через минуту", show_alert=True)
