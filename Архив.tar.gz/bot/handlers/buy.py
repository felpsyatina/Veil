from aiogram import Router, F
from aiogram.types import CallbackQuery

from ..keyboards.menus import plans_menu, payment_method_menu
from .. import api_client

router = Router()


@router.callback_query(F.data == "buy")
async def show_plans(callback: CallbackQuery):
    plans = await api_client.get_plans()
    if not plans:
        await callback.answer("Тарифы временно недоступны", show_alert=True)
        return
    await callback.message.edit_text(
        "Выберите тариф:",
        reply_markup=plans_menu(plans),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("plan:"))
async def show_payment_methods(callback: CallbackQuery):
    plan_id = int(callback.data.split(":")[1])
    await callback.message.edit_text(
        "Выберите способ оплаты:",
        reply_markup=payment_method_menu(plan_id),
    )
    await callback.answer()
