from aiogram import Router, F
from aiogram.filters import CommandStart, CommandObject
from aiogram.types import Message, CallbackQuery
import httpx

from ..keyboards.menus import main_menu
from .. import api_client
from ..config import BOT_USERNAME

router = Router()

WELCOME_TEXT = (
    "👋 Добро пожаловать!\n\n"
    "Здесь можно оформить подписку на VPN с серверами в нескольких странах "
    "и высокой устойчивостью к блокировкам.\n\n"
    "Выберите действие:"
)


@router.message(CommandStart(deep_link=True))
async def cmd_start_with_ref(message: Message, command: CommandObject):
    """/start 12345 — 12345 это telegram_id пригласившего."""
    ref_telegram_id = None
    if command.args and command.args.isdigit():
        ref_telegram_id = int(command.args)

    info = await api_client.register(
        telegram_id=message.from_user.id,
        username=message.from_user.username,
        ref_telegram_id=ref_telegram_id,
    )

    text = WELCOME_TEXT
    if ref_telegram_id and info.get("has_referrer"):
        text = "🎉 Вы пришли по приглашению!\n\n" + WELCOME_TEXT

    await message.answer(text, reply_markup=main_menu(trial_available=not info["trial_used"]))


@router.message(CommandStart())
async def cmd_start(message: Message):
    info = await api_client.register(
        telegram_id=message.from_user.id,
        username=message.from_user.username,
    )
    await message.answer(WELCOME_TEXT, reply_markup=main_menu(trial_available=not info["trial_used"]))


@router.callback_query(F.data == "back_main")
async def back_main(callback: CallbackQuery):
    status = await api_client.get_status(callback.from_user.id)
    trial_available = not status["trial_used"] if status else True
    await callback.message.edit_text(WELCOME_TEXT, reply_markup=main_menu(trial_available=trial_available))
    await callback.answer()


@router.callback_query(F.data == "trial")
async def start_trial(callback: CallbackQuery):
    try:
        result = await api_client.start_trial(
            telegram_id=callback.from_user.id,
            username=callback.from_user.username,
        )
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 400:
            await callback.answer("Пробный период уже был использован", show_alert=True)
        else:
            await callback.answer("Не удалось активировать пробный период, попробуйте позже", show_alert=True)
        return
    except Exception:
        await callback.answer("Сервис временно недоступен, попробуйте позже", show_alert=True)
        return

    await callback.message.edit_text(
        "🎁 Пробный период активирован!\n\n"
        f"Ссылка на подписку:\n`{result['sub_url']}`\n\n"
        "Вставьте её в приложение (v2rayNG, NekoBox, Hiddify, Streisand) "
        "как источник подписки.",
        parse_mode="Markdown",
        reply_markup=main_menu(trial_available=False),
    )
    await callback.answer()


@router.callback_query(F.data == "referral")
async def referral_info(callback: CallbackQuery):
    status = await api_client.get_status(callback.from_user.id)
    ref_count = status["referral_count"] if status else 0
    link = f"https://t.me/{BOT_USERNAME}?start={callback.from_user.id}"

    await callback.message.edit_text(
        "👥 *Реферальная программа*\n\n"
        "Приглашайте друзей — за каждую первую оплату приглашённого вы "
        "получаете бонусные дни подписки.\n\n"
        f"Ваша ссылка:\n`{link}`\n\n"
        f"Уже приглашено: {ref_count} чел.",
        parse_mode="Markdown",
        reply_markup=main_menu(trial_available=False, back_only=True),
    )
    await callback.answer()
