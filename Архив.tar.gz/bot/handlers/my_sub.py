from datetime import datetime
from aiogram import Router, F
from aiogram.types import CallbackQuery

from ..keyboards.menus import back_to_menu
from .. import api_client
from ..config import SUPPORT_USERNAME

router = Router()


@router.callback_query(F.data == "my_sub")
async def my_subscription(callback: CallbackQuery):
    status = await api_client.get_status(callback.from_user.id)

    if not status or not status["nodes"]:
        await callback.message.edit_text(
            "У вас пока нет активной подписки.",
            reply_markup=back_to_menu(),
        )
        await callback.answer()
        return

    lines = ["📱 Ваша подписка:\n", f"`{status['sub_url']}`\n"]
    for n in status["nodes"]:
        expiry = datetime.fromtimestamp(n["expiry_ms"] / 1000).strftime("%d.%m.%Y") if n["expiry_ms"] else "∞"
        state = "🟢" if n["enabled"] else "🔴"
        lines.append(f"{state} {n['country']} ({n['node']}) — до {expiry}")

    if status.get("referral_count"):
        lines.append(f"\n👥 Приглашено рефералов: {status['referral_count']}")

    await callback.message.edit_text(
        "\n".join(lines),
        parse_mode="Markdown",
        reply_markup=back_to_menu(),
    )
    await callback.answer()


@router.callback_query(F.data == "howto")
async def howto(callback: CallbackQuery):
    text = (
        "📖 *Как подключиться*\n\n"
        "1. Установите приложение:\n"
        "   • Android — v2rayNG или NekoBox\n"
        "   • iOS — Streisand или Shadowrocket\n"
        "   • Windows/macOS — Hiddify или NekoRay\n\n"
        "2. Скопируйте ссылку подписки из раздела «Моя подписка»\n"
        "3. В приложении: добавить подписку по URL → вставить ссылку → обновить\n"
        "4. Выберите сервер из списка и подключитесь\n\n"
        "Если один сервер не работает — просто переключитесь на другой "
        "в том же приложении, все они в одной подписке."
    )
    await callback.message.edit_text(text, parse_mode="Markdown", reply_markup=back_to_menu())
    await callback.answer()


@router.callback_query(F.data == "support")
async def support(callback: CallbackQuery):
    await callback.message.edit_text(
        f"По любым вопросам пишите: @{SUPPORT_USERNAME}",
        reply_markup=back_to_menu(),
    )
    await callback.answer()
