import os

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:8000")
INTERNAL_API_KEY = os.getenv("INTERNAL_API_KEY", "change-me-to-a-random-secret")

# Крипто-платежи: например NOWPayments и подобные
NOWPAYMENTS_API_KEY = os.getenv("NOWPAYMENTS_API_KEY", "")

# Российские карты через ЮKassa (yookassa.ru)
YOOKASSA_SHOP_ID = os.getenv("YOOKASSA_SHOP_ID", "")
YOOKASSA_SECRET_KEY = os.getenv("YOOKASSA_SECRET_KEY", "")

SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "your_support_username")
BOT_USERNAME = os.getenv("BOT_USERNAME", "your_bot_username")  # без @, для реферальных ссылок t.me/<username>?start=...
