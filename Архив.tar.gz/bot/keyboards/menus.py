from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu(trial_available: bool = False, back_only: bool = False) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()

    if back_only:
        kb.button(text="⬅️ Назад", callback_data="back_main")
        kb.adjust(1)
        return kb.as_markup()

    if trial_available:
        kb.button(text="🎁 Бесплатный пробный период", callback_data="trial")
    kb.button(text="🛒 Купить подписку", callback_data="buy")
    kb.button(text="📱 Моя подписка", callback_data="my_sub")
    kb.button(text="👥 Пригласить друга", callback_data="referral")
    kb.button(text="❓ Как подключиться", callback_data="howto")
    kb.button(text="🆘 Поддержка", callback_data="support")
    kb.adjust(1)
    return kb.as_markup()


def plans_menu(plans: list[dict]) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for p in plans:
        price = f"{p['price_rub']}₽" if p.get("price_rub") else (f"{p['price_stars']}⭐" if p.get("price_stars") else f"${p['price_usdt']}")
        kb.button(text=f"{p['name']} — {price}", callback_data=f"plan:{p['id']}")
    kb.button(text="⬅️ Назад", callback_data="back_main")
    kb.adjust(1)
    return kb.as_markup()


def payment_method_menu(plan_id: int) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="💳 Карта РФ (МИР/Visa/MC)", callback_data=f"pay:card:{plan_id}")
    kb.button(text="⭐ Telegram Stars", callback_data=f"pay:stars:{plan_id}")
    kb.button(text="💰 Крипта (USDT)", callback_data=f"pay:crypto:{plan_id}")
    kb.button(text="⬅️ Назад", callback_data="buy")
    kb.adjust(1)
    return kb.as_markup()


def back_to_menu() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="⬅️ В меню", callback_data="back_main")
    kb.adjust(1)
    return kb.as_markup()
