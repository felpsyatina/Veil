"""
Тонкая обёртка над внутренним API бэкенда. Используется хендлерами бота.

Один общий httpx.AsyncClient на весь процесс бота — переиспользует
соединения вместо того, чтобы поднимать новое TCP/TLS-соединение на
каждый вызов бэкенда.
"""
import httpx
from .config import BACKEND_URL, INTERNAL_API_KEY

_headers = {"x-api-key": INTERNAL_API_KEY}
_client: httpx.AsyncClient | None = None


def _get_client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        _client = httpx.AsyncClient(base_url=BACKEND_URL, headers=_headers, timeout=15)
    return _client


async def register(telegram_id: int, username: str | None = None, ref_telegram_id: int | None = None) -> dict:
    params = {"telegram_id": telegram_id}
    if username:
        params["username"] = username
    if ref_telegram_id:
        params["ref_telegram_id"] = ref_telegram_id
    resp = await _get_client().post("/internal/register", params=params)
    resp.raise_for_status()
    return resp.json()


async def start_trial(telegram_id: int, username: str | None = None) -> dict:
    params = {"telegram_id": telegram_id}
    if username:
        params["username"] = username
    resp = await _get_client().post("/internal/trial", params=params, timeout=30)
    resp.raise_for_status()
    return resp.json()


async def get_plans() -> list[dict]:
    resp = await _get_client().get("/internal/plans")
    resp.raise_for_status()
    return resp.json()


async def create_order(telegram_id: int, plan_id: int, payment_method: str, username: str | None = None) -> int:
    params = {
        "telegram_id": telegram_id,
        "plan_id": plan_id,
        "payment_method": payment_method,
    }
    if username:
        params["username"] = username
    resp = await _get_client().post("/internal/orders", params=params)
    resp.raise_for_status()
    return resp.json()["order_id"]


async def confirm_order(order_id: int, payment_ref: str | None = None) -> dict:
    params = {"payment_ref": payment_ref} if payment_ref else {}
    resp = await _get_client().post(
        f"/internal/orders/{order_id}/confirm",
        params=params,
        timeout=30,  # провижининг на нескольких нодах может занять время
    )
    resp.raise_for_status()
    return resp.json()


async def get_status(telegram_id: int) -> dict | None:
    resp = await _get_client().get(f"/internal/status/{telegram_id}")
    if resp.status_code == 404:
        return None
    resp.raise_for_status()
    return resp.json()
