from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, BigInteger, Boolean, DateTime, ForeignKey, create_engine
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from .config import DATABASE_URL

Base = declarative_base()


class Node(Base):
    """VPS-нода с установленной 3x-ui панелью"""
    __tablename__ = "nodes"

    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True)            # "nl-1", "de-2" и т.д.
    api_url = Column(String)                       # https://node-ip:port/panel_path
    api_username = Column(String)
    api_password = Column(String)
    subscription_domain = Column(String)           # домен/IP, который видит клиент
    inbound_id = Column(Integer)                   # id инбаунда VLESS+Reality в 3x-ui
    is_active = Column(Boolean, default=True)
    max_users = Column(Integer, default=500)
    country_code = Column(String, default="NL")
    last_check_failed = Column(Boolean, default=False)  # для health_check.py — не спамить алертами


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, index=True)
    username = Column(String, nullable=True)
    sub_token = Column(String, unique=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    trial_used = Column(Boolean, default=False)
    referred_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    referral_bonus_given = Column(Boolean, default=False)  # рефереру начислен бонус за этого юзера

    subscriptions = relationship("UserNodeAccount", back_populates="user")
    orders = relationship("Order", back_populates="user")
    referred_by = relationship("User", remote_side=[id])


class UserNodeAccount(Base):
    """Связь пользователь <-> нода: его uuid/email на конкретной ноде"""
    __tablename__ = "user_node_accounts"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    node_id = Column(Integer, ForeignKey("nodes.id"))

    xui_client_uuid = Column(String)
    xui_client_email = Column(String)
    expiry_time = Column(BigInteger)         # unix ms
    total_gb = Column(Integer, default=0)    # 0 = безлимит
    enabled = Column(Boolean, default=True)

    user = relationship("User", back_populates="subscriptions")
    node = relationship("Node")


class Plan(Base):
    """Тарифный план"""
    __tablename__ = "plans"

    id = Column(Integer, primary_key=True)
    name = Column(String)
    duration_days = Column(Integer)
    total_gb = Column(Integer, default=0)
    price_stars = Column(Integer, nullable=True)     # цена в Telegram Stars
    price_usdt = Column(String, nullable=True)        # цена в USDT (строкой, для точности)
    price_rub = Column(String, nullable=True)          # цена в рублях, для оплаты картой РФ
    max_nodes = Column(Integer, default=999)
    is_active = Column(Boolean, default=True)
    sort_order = Column(Integer, default=0)


class Order(Base):
    """Заказ/платёж"""
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    plan_id = Column(Integer, ForeignKey("plans.id"))
    status = Column(String, default="pending")   # pending / paid / failed / expired
    payment_method = Column(String)                # stars / crypto
    payment_ref = Column(String, nullable=True)     # id платежа в шлюзе
    created_at = Column(DateTime, default=datetime.utcnow)
    paid_at = Column(DateTime, nullable=True)

    user = relationship("User", back_populates="orders")
    plan = relationship("Plan")


engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)


def init_db():
    Base.metadata.create_all(engine)


def seed_default_plans():
    """Заполняет дефолтные тарифы при первом запуске, если таблица пустая."""
    db = SessionLocal()
    try:
        if db.query(Plan).count() > 0:
            return
        defaults = [
            Plan(name="1 месяц", duration_days=30, total_gb=0, price_stars=250, price_usdt="4.99", price_rub="449", sort_order=1),
            Plan(name="3 месяца", duration_days=90, total_gb=0, price_stars=650, price_usdt="12.99", price_rub="1149", sort_order=2),
            Plan(name="12 месяцев", duration_days=365, total_gb=0, price_stars=2200, price_usdt="39.99", price_rub="3599", sort_order=3),
        ]
        db.add_all(defaults)
        db.commit()
    finally:
        db.close()
