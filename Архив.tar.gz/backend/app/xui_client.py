"""
Клиент для 3x-ui panel API.
Работает через сессионные cookies (панель использует form-based auth, не Bearer-токены).
"""
import json
import uuid
import httpx
from typing import Optional
from urllib.parse import quote


class XUIClient:
    def __init__(self, base_url: str, username: str, password: str, verify_ssl: bool | None = None):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        if verify_ssl is None:
            from .config import XUI_VERIFY_SSL
            verify_ssl = XUI_VERIFY_SSL
        self._client = httpx.Client(base_url=self.base_url, timeout=15.0, verify=verify_ssl)
        self._logged_in = False

    def login(self):
        resp = self._client.post(
            "/login",
            data={"username": self.username, "password": self.password},
        )
        resp.raise_for_status()
        data = resp.json()
        if not data.get("success"):
            raise RuntimeError(f"3x-ui login failed: {data}")
        self._logged_in = True

    def _ensure_login(self):
        if not self._logged_in:
            self.login()

    def _request(self, method: str, path: str, **kwargs) -> dict:
        self._ensure_login()
        resp = self._client.request(method, path, **kwargs)
        if resp.status_code == 401:
            # сессия протухла — логинимся заново и повторяем один раз
            self.login()
            resp = self._client.request(method, path, **kwargs)
        resp.raise_for_status()
        return resp.json()

    def get_inbound(self, inbound_id: int) -> dict:
        data = self._request("GET", f"/panel/api/inbounds/get/{inbound_id}")
        return data["obj"]

    def add_client(
        self,
        inbound_id: int,
        email: str,
        expiry_time_ms: int = 0,
        total_gb: int = 0,
        client_uuid: Optional[str] = None,
    ) -> str:
        """
        Добавляет клиента в инбаунд (VLESS). Возвращает uuid клиента.
        expiry_time_ms: unix-время в мс, 0 = без ограничения по времени
        total_gb: лимит трафика в ГБ, 0 = безлимит
        """
        client_uuid = client_uuid or str(uuid.uuid4())

        client_settings = {
            "clients": [
                {
                    "id": client_uuid,
                    "email": email,
                    "enable": True,
                    "expiryTime": expiry_time_ms,
                    "totalGB": total_gb * 1024 ** 3,
                    "flow": "xtls-rprx-vision",  # для Reality
                }
            ]
        }

        payload = {
            "id": inbound_id,
            "settings": json.dumps(client_settings),
        }
        data = self._request("POST", "/panel/api/inbounds/addClient", json=payload)
        if not data.get("success"):
            raise RuntimeError(f"addClient failed: {data}")
        return client_uuid

    def update_client(
        self,
        inbound_id: int,
        client_uuid: str,
        email: str,
        expiry_time_ms: int,
        total_gb: int,
        enable: bool = True,
    ):
        client_settings = {
            "clients": [
                {
                    "id": client_uuid,
                    "email": email,
                    "enable": enable,
                    "expiryTime": expiry_time_ms,
                    "totalGB": total_gb * 1024 ** 3,
                    "flow": "xtls-rprx-vision",
                }
            ]
        }
        payload = {"id": inbound_id, "settings": json.dumps(client_settings)}
        data = self._request("POST", f"/panel/api/inbounds/updateClient/{client_uuid}", json=payload)
        if not data.get("success"):
            raise RuntimeError(f"updateClient failed: {data}")

    def delete_client(self, inbound_id: int, client_uuid: str):
        data = self._request("POST", f"/panel/api/inbounds/{inbound_id}/delClient/{client_uuid}")
        if not data.get("success"):
            raise RuntimeError(f"delClient failed: {data}")

    def get_client_traffic(self, email: str) -> dict:
        data = self._request("GET", f"/panel/api/inbounds/getClientTraffics/{email}")
        return data.get("obj") or {}

    def build_vless_link(
        self,
        inbound: dict,
        client_uuid: str,
        remark: str,
        server_host: str,
    ) -> str:
        """
        Собирает vless:// ссылку вручную из настроек инбаунда (Reality).
        Так надёжнее, чем полагаться на встроенный /sub/ 3x-ui, если нужно
        подставить свой server_host (например, домен вместо IP ноды).
        """
        stream = json.loads(inbound["streamSettings"])
        reality = stream["realitySettings"]["settings"]
        reality_srv = stream["realitySettings"]

        params = {
            "type": stream["network"],
            "security": "reality",
            "pbk": reality["publicKey"],
            "fp": reality.get("fingerprint", "chrome"),
            "sni": reality_srv["serverNames"][0],
            "sid": reality_srv["shortIds"][0],
            "spx": reality.get("spiderX", "/"),
            "flow": "xtls-rprx-vision",
        }
        query = "&".join(f"{k}={quote(str(v), safe='')}" for k, v in params.items())
        port = inbound["port"]
        return f"vless://{client_uuid}@{server_host}:{port}?{query}#{quote(remark, safe='')}"
