"""
Регистрирует ноду в базе бэкенда после того, как на ней создан
Reality-инбаунд скриптом setup_node.py.

Запускать из окружения, где доступен backend/app (например, внутри
контейнера backend: docker compose exec backend python -m app.register_node ...)
"""
import argparse
from .db import SessionLocal, Node, init_db


def register_node(
    name: str,
    api_url: str,
    api_username: str,
    api_password: str,
    subscription_domain: str,
    inbound_id: int,
    country_code: str,
):
    db = SessionLocal()
    try:
        existing = db.query(Node).filter_by(name=name).first()
        if existing:
            print(f"Нода '{name}' уже есть, обновляю параметры")
            node = existing
        else:
            node = Node(name=name)
            db.add(node)

        node.api_url = api_url
        node.api_username = api_username
        node.api_password = api_password
        node.subscription_domain = subscription_domain
        node.inbound_id = inbound_id
        node.country_code = country_code
        node.is_active = True

        db.commit()
        print(f"Нода '{name}' сохранена (id={node.id})")
    finally:
        db.close()


if __name__ == "__main__":
    init_db()
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--api-url", required=True)
    parser.add_argument("--api-user", required=True)
    parser.add_argument("--api-password", required=True)
    parser.add_argument("--sub-domain", required=True, help="IP или домен, который увидит клиент в конфиге")
    parser.add_argument("--inbound-id", type=int, required=True)
    parser.add_argument("--country", default="NL")
    args = parser.parse_args()

    register_node(
        name=args.name,
        api_url=args.api_url,
        api_username=args.api_user,
        api_password=args.api_password,
        subscription_domain=args.sub_domain,
        inbound_id=args.inbound_id,
        country_code=args.country,
    )
