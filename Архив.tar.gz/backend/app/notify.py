"""
Лёгкий хелпер для отправки сообщений через Telegram Bot API напрямую из
бэкенда — без зависимости от aiogram. Используется для:
  - уведомления реферера о начисленном бонусе
  - алертов о падении/недоступности нод (health_check.py)
"""
import httpx
from .config import BOT_TOKEN


def send_telegram_message(chat_id: str | int, text: str, parse_mode: str = "Markdown") -> bool:
    if not BOT_TOKEN:
        print("BOT_TOKEN не задан в окружении бэкенда — уведомление не отправлено")
        return False

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    try:
        resp = httpx.post(
            url,
            json={"chat_id": chat_id, "text": text, "parse_mode": parse_mode},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json().get("ok", False)
    except Exception as e:
        print(f"не удалось отправить телеграм-уведомление: {e}")
        return False
