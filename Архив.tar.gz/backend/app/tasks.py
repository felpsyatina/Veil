"""
Периодическая задача: находит истёкшие подписки и отключает их на нодах.
Запускать через cron / celery beat раз в 10-15 минут.
"""
import time
from .db import SessionLocal, UserNodeAccount
from .subscription import disable_user_on_node


def deactivate_expired():
    db = SessionLocal()
    now_ms = int(time.time() * 1000)
    try:
        expired = (
            db.query(UserNodeAccount)
            .filter(UserNodeAccount.enabled == True)  # noqa: E712
            .filter(UserNodeAccount.expiry_time > 0)
            .filter(UserNodeAccount.expiry_time < now_ms)
            .all()
        )
        for account in expired:
            try:
                disable_user_on_node(db, account)
                print(f"disabled expired account: user={account.user_id} node={account.node.name}")
            except Exception as e:
                print(f"failed to disable {account.id}: {e}")
    finally:
        db.close()


if __name__ == "__main__":
    deactivate_expired()
