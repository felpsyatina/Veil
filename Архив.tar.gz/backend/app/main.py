import time
from datetime import datetime
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session

from .db import SessionLocal, User, Node, Plan, Order, init_db, seed_default_plans
from .subscription import (
    build_merged_subscription,
    provision_user_on_node,
    extend_user_all_nodes,
    generate_sub_token,
)
from .config import INTERNAL_API_KEY, PUBLIC_DOMAIN, TRIAL_DAYS, TRIAL_GB, REFERRAL_BONUS_DAYS
from .notify import send_telegram_message

app = FastAPI(title="VPN Subscription Backend")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def check_internal_key(x_api_key: str = Header(...)):
    """Все /internal/* эндпоинты вызывает только бот, по секретному ключу."""
    if x_api_key != INTERNAL_API_KEY:
        raise HTTPException(403, "forbidden")


def sub_url_for(token: str) -> str:
    return f"https://{PUBLIC_DOMAIN}/sub/{token}"


def get_or_create_user(db: Session, telegram_id: int, username: str | None = None) -> User:
    user = db.query(User).filter_by(telegram_id=telegram_id).first()
    if not user:
        user = User(telegram_id=telegram_id, username=username, sub_token=generate_sub_token())
        db.add(user)
        db.commit()
        db.refresh(user)
    return user


# ---------- Публичный эндпоинт: подписка для VPN-клиента ----------

@app.get("/sub/{sub_token}", response_class=PlainTextResponse)
def get_subscription(sub_token: str, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(sub_token=sub_token).first()
    if not user:
        raise HTTPException(404, "not found")
    return build_merged_subscription(db, user)


# ---------- Внутренний API для бота ----------

@app.post("/internal/register", dependencies=[Depends(check_internal_key)])
def register(telegram_id: int, username: str | None = None, ref_telegram_id: int | None = None, db: Session = Depends(get_db)):
    """
    Вызывается ботом на /start. Создаёт пользователя, если его ещё нет,
    и один раз фиксирует, кто его пригласил (реферальную привязку нельзя
    поменять задним числом).
    """
    user = get_or_create_user(db, telegram_id, username)

    if user.referred_by_id is None and ref_telegram_id and ref_telegram_id != telegram_id:
        referrer = db.query(User).filter_by(telegram_id=ref_telegram_id).first()
        if referrer:
            user.referred_by_id = referrer.id
            db.commit()

    return {"trial_used": user.trial_used, "has_referrer": user.referred_by_id is not None}


@app.get("/internal/plans", dependencies=[Depends(check_internal_key)])
def list_plans(db: Session = Depends(get_db)):
    plans = db.query(Plan).filter_by(is_active=True).order_by(Plan.sort_order).all()
    return [
        {
            "id": p.id,
            "name": p.name,
            "duration_days": p.duration_days,
            "total_gb": p.total_gb,
            "price_stars": p.price_stars,
            "price_usdt": p.price_usdt,
            "price_rub": p.price_rub,
        }
        for p in plans
    ]


@app.post("/internal/trial", dependencies=[Depends(check_internal_key)])
def start_trial(telegram_id: int, username: str | None = None, db: Session = Depends(get_db)):
    user = get_or_create_user(db, telegram_id, username)
    if user.trial_used:
        raise HTTPException(400, "trial already used")

    expiry_ms = int((time.time() + TRIAL_DAYS * 86400) * 1000)
    nodes = db.query(Node).filter_by(is_active=True).all()
    if not nodes:
        raise HTTPException(500, "no active nodes")

    for node in nodes:
        provision_user_on_node(db, user, node, expiry_ms, TRIAL_GB)

    user.trial_used = True
    db.commit()

    return {"sub_url": sub_url_for(user.sub_token), "expiry_ms": expiry_ms}


@app.post("/internal/orders", dependencies=[Depends(check_internal_key)])
def create_order(telegram_id: int, plan_id: int, payment_method: str, username: str | None = None, db: Session = Depends(get_db)):
    """Создаёт заказ со статусом pending. Бот вызывает это перед выставлением счёта."""
    user = get_or_create_user(db, telegram_id, username)

    plan = db.query(Plan).filter_by(id=plan_id, is_active=True).first()
    if not plan:
        raise HTTPException(404, "plan not found")

    order = Order(user_id=user.id, plan_id=plan.id, status="pending", payment_method=payment_method)
    db.add(order)
    db.commit()
    db.refresh(order)
    return {"order_id": order.id}


def _maybe_reward_referrer(db: Session, user: User):
    """Начисляет бонусные дни рефереру за первую оплату приглашённого."""
    if not user.referred_by_id or user.referral_bonus_given:
        return

    paid_orders_count = db.query(Order).filter_by(user_id=user.id, status="paid").count()
    if paid_orders_count != 1:
        return  # бонус только за самую первую оплату

    referrer = db.query(User).filter_by(id=user.referred_by_id).first()
    if not referrer:
        return

    referrer_has_nodes = len(referrer.subscriptions) > 0
    if referrer_has_nodes:
        extend_user_all_nodes(db, referrer, REFERRAL_BONUS_DAYS)

    user.referral_bonus_given = True
    db.commit()

    if referrer_has_nodes:
        send_telegram_message(
            referrer.telegram_id,
            f"🎁 Ваш реферал оплатил подписку — вам начислено {REFERRAL_BONUS_DAYS} бонусных дней!",
        )


@app.post("/internal/orders/{order_id}/confirm", dependencies=[Depends(check_internal_key)])
def confirm_order(order_id: int, payment_ref: str | None = None, db: Session = Depends(get_db)):
    """
    Вызывается ботом после подтверждения оплаты. Провижинит пользователя
    на всех активных нодах и начисляет реферальный бонус пригласившему,
    если это первая оплата данного пользователя.
    """
    order = db.query(Order).filter_by(id=order_id).first()
    if not order:
        raise HTTPException(404, "order not found")
    if order.status == "paid":
        user = order.user
        return {"sub_url": sub_url_for(user.sub_token)}

    order.status = "paid"
    order.payment_ref = payment_ref
    order.paid_at = datetime.utcnow()
    db.commit()

    user = order.user
    plan = order.plan
    expiry_ms = int((time.time() + plan.duration_days * 86400) * 1000)

    nodes = db.query(Node).filter_by(is_active=True).limit(plan.max_nodes).all()
    if not nodes:
        raise HTTPException(500, "no active nodes")

    for node in nodes:
        provision_user_on_node(db, user, node, expiry_ms, plan.total_gb)

    _maybe_reward_referrer(db, user)

    return {"sub_url": sub_url_for(user.sub_token), "expiry_ms": expiry_ms}


@app.get("/internal/status/{telegram_id}", dependencies=[Depends(check_internal_key)])
def status(telegram_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(telegram_id=telegram_id).first()
    if not user:
        raise HTTPException(404, "not found")

    accounts = user.subscriptions
    referral_count = db.query(User).filter_by(referred_by_id=user.id).count()

    return {
        "sub_url": sub_url_for(user.sub_token),
        "trial_used": user.trial_used,
        "referral_count": referral_count,
        "nodes": [
            {"node": a.node.name, "country": a.node.country_code, "expiry_ms": a.expiry_time, "enabled": a.enabled}
            for a in accounts
        ],
    }


@app.on_event("startup")
def on_startup():
    init_db()
    seed_default_plans()
