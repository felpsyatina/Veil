"""
Логика объединения конфигов с разных нод в одну подписку.
"""
import base64
import secrets
from sqlalchemy.orm import Session

from .db import User, Node, UserNodeAccount
from .xui_client import XUIClient

# Кэш клиентов 3x-ui, чтобы не логиниться заново на каждый запрос
_xui_clients: dict[int, XUIClient] = {}


def get_xui_client(node: Node) -> XUIClient:
    if node.id not in _xui_clients:
        _xui_clients[node.id] = XUIClient(node.api_url, node.api_username, node.api_password)
    return _xui_clients[node.id]


def generate_sub_token() -> str:
    return secrets.token_urlsafe(24)


def provision_user_on_node(db: Session, user: User, node: Node, expiry_ms: int, total_gb: int) -> UserNodeAccount:
    """Создаёт (или обновляет) аккаунт пользователя на конкретной ноде."""
    client = get_xui_client(node)
    email = f"{user.sub_token[:8]}_{node.name}"  # уникальный идентификатор на ноде

    existing = (
        db.query(UserNodeAccount)
        .filter_by(user_id=user.id, node_id=node.id)
        .first()
    )

    if existing:
        client.update_client(
            inbound_id=node.inbound_id,
            client_uuid=existing.xui_client_uuid,
            email=email,
            expiry_time_ms=expiry_ms,
            total_gb=total_gb,
            enable=True,
        )
        existing.expiry_time = expiry_ms
        existing.total_gb = total_gb
        existing.enabled = True
        db.commit()
        return existing

    client_uuid = client.add_client(
        inbound_id=node.inbound_id,
        email=email,
        expiry_time_ms=expiry_ms,
        total_gb=total_gb,
    )

    account = UserNodeAccount(
        user_id=user.id,
        node_id=node.id,
        xui_client_uuid=client_uuid,
        xui_client_email=email,
        expiry_time=expiry_ms,
        total_gb=total_gb,
        enabled=True,
    )
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


def extend_user_all_nodes(db: Session, user: User, bonus_days: int):
    """
    Продлевает все активные аккаунты пользователя на bonus_days.
    Используется для начисления реферального бонуса.
    Если аккаунт уже истёк, отсчёт бонуса идёт от текущего момента, а не от
    старой даты истечения — иначе бонус на мёртвый аккаунт был бы бесполезен.
    """
    import time

    now_ms = int(time.time() * 1000)
    bonus_ms = bonus_days * 86400 * 1000

    accounts = db.query(UserNodeAccount).filter_by(user_id=user.id).all()
    for account in accounts:
        base = account.expiry_time if account.expiry_time and account.expiry_time > now_ms else now_ms
        new_expiry = base + bonus_ms

        node = account.node
        client = get_xui_client(node)
        client.update_client(
            inbound_id=node.inbound_id,
            client_uuid=account.xui_client_uuid,
            email=account.xui_client_email,
            expiry_time_ms=new_expiry,
            total_gb=account.total_gb,
            enable=True,
        )
        account.expiry_time = new_expiry
        account.enabled = True

    db.commit()


def disable_user_on_node(db: Session, account: UserNodeAccount):
    node = account.node
    client = get_xui_client(node)
    client.update_client(
        inbound_id=node.inbound_id,
        client_uuid=account.xui_client_uuid,
        email=account.xui_client_email,
        expiry_time_ms=account.expiry_time,
        total_gb=account.total_gb,
        enable=False,
    )
    account.enabled = False
    db.commit()


def build_merged_subscription(db: Session, user: User) -> str:
    """
    Возвращает base64-строку со всеми vless-ссылками пользователя
    со всех нод, где у него активный (не отключённый) аккаунт.
    Формат совместим с v2rayNG / NekoBox / Hiddify и т.п.
    """
    lines = []

    accounts = (
        db.query(UserNodeAccount)
        .filter_by(user_id=user.id, enabled=True)
        .all()
    )

    for account in accounts:
        node = account.node
        if not node.is_active:
            continue

        client = get_xui_client(node)
        try:
            inbound = client.get_inbound(node.inbound_id)
        except Exception:
            # нода недоступна — пропускаем, не валим всю подписку
            continue

        remark = f"{node.country_code}-{node.name}"
        link = client.build_vless_link(
            inbound=inbound,
            client_uuid=account.xui_client_uuid,
            remark=remark,
            server_host=node.subscription_domain,
        )
        lines.append(link)

    raw = "\n".join(lines)
    return base64.b64encode(raw.encode()).decode()
