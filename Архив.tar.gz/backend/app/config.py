import os

INTERNAL_API_KEY = os.getenv("INTERNAL_API_KEY", "change-me-to-a-random-secret")
PUBLIC_DOMAIN = os.getenv("PUBLIC_DOMAIN", "your-domain.com")
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://vpnuser:vpnpass@postgres:5432/vpnbot")

# для оплаты через крипто-шлюз (NOWPayments и подобные)
CRYPTO_IPN_SECRET = os.getenv("CRYPTO_IPN_SECRET", "")

# триал
TRIAL_DAYS = int(os.getenv("TRIAL_DAYS", "3"))
TRIAL_GB = int(os.getenv("TRIAL_GB", "5"))  # 0 = безлимит

# реферальная программа: рефереру начисляются бонусные дни за первую
# оплату приглашённого пользователя
REFERRAL_BONUS_DAYS = int(os.getenv("REFERRAL_BONUS_DAYS", "7"))

# токен бота нужен бэкенду только для двух вещей: уведомление реферера
# о бонусе и алерты о падении нод. Это тот же токен, что и у бота.
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "")  # telegram_id админа/чата для алертов о нодах

# 3x-ui панель по умолчанию у большинства инсталляций поднята на самоподписанном
# сертификате (или вообще без TLS). Проверка сертификата по умолчанию выключена,
# чтобы это не роняло бэкенд на пустом месте — включите (true), когда поставите
# на ноды нормальные сертификаты.
XUI_VERIFY_SSL = os.getenv("XUI_VERIFY_SSL", "false").lower() in ("1", "true", "yes")
