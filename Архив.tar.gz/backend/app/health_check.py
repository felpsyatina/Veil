"""
Проверяет доступность каждой активной ноды (логин в 3x-ui + получение
инбаунда) и шлёт алерт в Telegram, если нода стала недоступна или
восстановилась.

Запускать по крону, например раз в 5 минут:
    */5 * * * * docker compose exec -T backend python -m app.health_check

Флаг last_check_failed в таблице Node нужен, чтобы слать алерт только
при смене статуса, а не при каждом запуске.
"""
from .db import SessionLocal, Node
from .xui_client import XUIClient
from .notify import send_telegram_message
from .config import ADMIN_CHAT_ID


def check_node(node: Node) -> tuple[bool, str]:
    """Возвращает (ok, детали_ошибки)."""
    try:
        client = XUIClient(node.api_url, node.api_username, node.api_password)
        client.login()
        client.get_inbound(node.inbound_id)
        return True, ""
    except Exception as e:
        return False, str(e)


def run_health_check():
    db = SessionLocal()
    try:
        nodes = db.query(Node).filter_by(is_active=True).all()
        for node in nodes:
            ok, error = check_node(node)
            was_failed = node.last_check_failed

            if not ok and not was_failed:
                if ADMIN_CHAT_ID:
                    send_telegram_message(
                        ADMIN_CHAT_ID,
                        f"🔴 Нода *{node.name}* ({node.country_code}) недоступна.\n"
                        f"Ошибка: `{error}`\n\n"
                        f"Возможные причины: упала 3x-ui, сменился пароль, "
                        f"или IP попал в блокировку — стоит проверить доступность "
                        f"из РФ отдельно.",
                    )
                node.last_check_failed = True
                db.commit()

            elif ok and was_failed:
                if ADMIN_CHAT_ID:
                    send_telegram_message(
                        ADMIN_CHAT_ID,
                        f"🟢 Нода *{node.name}* ({node.country_code}) снова доступна.",
                    )
                node.last_check_failed = False
                db.commit()

            print(f"{node.name}: {'OK' if ok else 'FAIL — ' + error}")
    finally:
        db.close()


if __name__ == "__main__":
    run_health_check()
